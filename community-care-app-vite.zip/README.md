# CommunityCare Delivery (Vite + React + Tailwind)

A lightweight, accessible app for elderly/disabled support requests. Uses localStorage for persistence; easy to swap to Supabase/Firebase later.

## Quick start
```bash
npm install
npm run dev
# open http://localhost:5173
```

## Build and deploy
```bash
npm run build
npm run preview   # to test production build locally
```

Deploy on Vercel/Netlify. Repo works out of the box.

## Tech
- React 18 + Vite
- Tailwind CSS
- No external UI libs
- LocalStorage queue (replaceable)
