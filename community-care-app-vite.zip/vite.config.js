import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
// If plugin is missing, vite still runs fine with modern JSX transform.
export default defineConfig({
  plugins: [react()],
})
