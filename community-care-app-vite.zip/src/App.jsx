import React, { useEffect, useMemo, useState } from "react";

const uid = () => Math.random().toString(36).slice(2, 10);

export default function App() {
  // Accessibility & layout
  const [largeText, setLargeText] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [volunteerMode, setVolunteerMode] = useState(false);

  // Form state
  const [type, setType] = useState("Medication");
  const [items, setItems] = useState("");
  const [notes, setNotes] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [eircode, setEircode] = useState("");
  const [contactMethod, setContactMethod] = useState("Phone");
  const [preferredDate, setPreferredDate] = useState("");
  const [preferredTime, setPreferredTime] = useState("");
  const [emergency, setEmergency] = useState(false);
  const [consent, setConsent] = useState(false);
  const [submittedId, setSubmittedId] = useState(null);

  // Queue (localStorage persistence)
  const STORAGE_KEY = "communitycare_requests_v1";
  const [list, setList] = useState([]);
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setList(JSON.parse(raw));
    } catch {}
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
    } catch {}
  }, [list]);

  const add = (req) => setList((prev) => [req, ...prev]);
  const update = (id, patch) => setList((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  const remove = (id) => setList((prev) => prev.filter((r) => r.id !== id));

  // Icons (inline SVG, no deps)
  const Icon = ({ name, className = "w-5 h-5" }) => {
    const common = { className, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" };
    switch (name) {
      case "stethoscope":
        return (
          <svg {...common}><path d="M6 4v7a4 4 0 1 0 8 0V4"/><path d="M18 6a3 3 0 1 1-3 3"/><path d="M18 9v7a4 4 0 0 1-4 4H9"/></svg>
        );
      case "basket":
        return (
          <svg {...common}><path d="M5 11h14l-1 8H6l-1-8Z"/><path d="m7 11 5-7 5 7"/></svg>
        );
      case "clipboard":
        return (
          <svg {...common}><rect x="8" y="3" width="8" height="4" rx="1"/><path d="M9 7H7a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2"/></svg>
        );
      case "heart":
        return (
          <svg {...common}><path d="M20.8 11.6 12 20l-8.8-8.4A5.5 5.5 0 0 1 12 6a5.5 5.5 0 0 1 8.8 5.6Z"/></svg>
        );
      case "phone":
        return (
          <svg {...common}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.32 1.77.6 2.6a2 2 0 0 1-.45 2.11L8.1 9.9a16 16 0 0 0 6 6l1.46-1.16a2 2 0 0 1 2.11-.45c.83.28 1.7.48 2.6.6A2 2 0 0 1 22 16.92Z"/></svg>
        );
      case "calendar":
        return (
          <svg {...common}><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
        );
      case "map":
        return (
          <svg {...common}><path d="M9 18 3 21V5l6-3 6 3 6-3v16l-6 3-6-3Z"/><path d="M9 18V2m6 3v16"/></svg>
        );
      case "users":
        return (
          <svg {...common}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        );
      case "check":
        return (
          <svg {...common}><path d="M20 6 9 17l-5-5"/></svg>
        );
      case "send":
        return (
          <svg {...common}><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
        );
      default:
        return null;
    }
  };

  const iconForType = useMemo(() => {
    switch (type) {
      case "Medication":
        return <Icon name="stethoscope" />;
      case "Groceries":
        return <Icon name="basket" />;
      case "Errands":
        return <Icon name="clipboard" />;
      case "Wellbeing Check":
        return <Icon name="heart" />;
      default:
        return null;
    }
  }, [type]);

  const textScale = largeText ? "text-lg md:text-xl" : "text-base";
  const contrast = highContrast ? "contrast-125" : "";

  function validate() {
    const errs = [];
    if (!name.trim()) errs.push("Please enter your name.");
    if (!address.trim()) errs.push("Please enter your address.");
    if (!consent) errs.push("You must consent to data use to submit.");
    const hasPhone = phone.trim().length > 0;
    const hasEmail = email.trim().length > 0;
    if (!hasPhone && !hasEmail) errs.push("Provide at least a phone or an email.");
    if (!items.trim()) errs.push("Tell us what you need delivered or done.");
    return errs;
  }

  function resetForm() {
    setType("Medication");
    setItems("");
    setNotes("");
    setName("");
    setPhone("");
    setEmail("");
    setAddress("");
    setEircode("");
    setContactMethod("Phone");
    setPreferredDate("");
    setPreferredTime("");
    setEmergency(false);
    setConsent(false);
  }

  function handleSubmit(e) {
    e.preventDefault();
    const errs = validate();
    if (errs.length) {
      alert("Please fix:\n\n" + errs.join("\n"));
      return;
    }
    const req = {
      id: uid(),
      createdAt: new Date().toISOString(),
      type,
      items: items.trim(),
      notes: notes.trim() || undefined,
      name: name.trim(),
      phone: phone.trim() || undefined,
      email: email.trim() || undefined,
      address: address.trim(),
      eircode: eircode.trim() || undefined,
      contactMethod,
      preferredDate: preferredDate || undefined,
      preferredTime: preferredTime || undefined,
      emergency,
      consent,
      status: "Queued",
    };
    add(req);
    setSubmittedId(req.id);
    resetForm();
  }

  const pending = list.filter((r) => r.status !== "Completed");
  const completed = list.filter((r) => r.status === "Completed");

  return (
    <div className={`min-h-screen p-4 md:p-8 bg-gradient-to-b from-slate-50 to-white ${contrast}`} style={{ fontFamily: "Inter, Segoe UI, system-ui, -apple-system, Roboto, Helvetica, Arial, sans-serif" }}>
      <div className={`mx-auto max-w-6xl space-y-6 ${textScale}`}>
        {/* Header */}
        <header className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <h1 className="text-2xl md:text-4xl font-semibold tracking-tight text-slate-800">CommunityCare Delivery</h1>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2" role="group" aria-label="Accessibility controls">
              <input id="largeText" type="checkbox" checked={largeText} onChange={(e) => setLargeText(e.target.checked)} className="h-4 w-4" />
              <label htmlFor="largeText">Large text</label>
              <input id="highContrast" type="checkbox" checked={highContrast} onChange={(e) => setHighContrast(e.target.checked)} className="h-4 w-4 ml-2" />
              <label htmlFor="highContrast">High contrast</label>
            </div>
            <div className="flex items-center gap-2">
              <input id="volunteerMode" type="checkbox" checked={volunteerMode} onChange={(e) => setVolunteerMode(e.target.checked)} className="h-4 w-4" />
              <label htmlFor="volunteerMode" className="inline-flex items-center gap-1 text-blue-600"><Icon name="users" className="w-4 h-4" />Volunteer</label>
            </div>
          </div>
        </header>

        {/* Hero / Intro */}
        <div className="border rounded-2xl shadow-md bg-white">
          <div className="px-5 py-4 border-b">
            <div className="flex items-center gap-2 text-blue-700 font-medium">
              <Icon name="phone" />
              <span>Get support with deliveries</span>
            </div>
          </div>
          <div className="p-5">
            <p className="text-slate-700">This app helps older adults and disabled neighbours request safe deliveries of medication, groceries, and essential errands. Fill out the form and one of our volunteers will contact you.</p>
          </div>
        </div>

        {/* Request Form */}
        <form onSubmit={handleSubmit} className="grid md:grid-cols-3 gap-4" aria-labelledby="requestFormHeading">
          <div className="md:col-span-2 border rounded-2xl shadow-md bg-white">
            <div className="px-5 py-4 border-b">
              <h2 id="requestFormHeading" className="flex items-center gap-2 text-blue-700 font-medium">{iconForType}<span>What do you need?</span></h2>
            </div>
            <div className="p-5 space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="type" className="block text-sm font-medium mb-1">Request type</label>
                  <select id="type" value={type} onChange={(e) => setType(e.target.value)} className="w-full border rounded-lg px-3 py-2">
                    <option>Medication</option>
                    <option>Groceries</option>
                    <option>Errands</option>
                    <option>Wellbeing Check</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4" role="group" aria-label="Preferred date and time">
                  <div>
                    <label htmlFor="preferredDate" className="block text-sm font-medium mb-1">Preferred date</label>
                    <input id="preferredDate" type="date" value={preferredDate} onChange={(e) => setPreferredDate(e.target.value)} className="w-full border rounded-lg px-3 py-2" />
                  </div>
                  <div>
                    <label htmlFor="preferredTime" className="block text-sm font-medium mb-1">Preferred time</label>
                    <input id="preferredTime" type="time" value={preferredTime} onChange={(e) => setPreferredTime(e.target.value)} className="w-full border rounded-lg px-3 py-2" />
                  </div>
                </div>
              </div>

              <div>
                <label htmlFor="items" className="block text-sm font-medium mb-1">What should we deliver / do?</label>
                <textarea id="items" value={items} onChange={(e) => setItems(e.target.value)} rows={5} className="w-full border rounded-lg px-3 py-2" placeholder="e.g., Collect prescription; 2L milk, bread, eggs; Top-up electricity card" />
              </div>

              <div>
                <label htmlFor="notes" className="block text-sm font-medium mb-1">Notes for volunteers (optional)</label>
                <textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className="w-full border rounded-lg px-3 py-2" placeholder="Gate code, mobility needs, pet at home, etc." />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-1">Your name</label>
                  <input id="name" value={name} onChange={(e) => setName(e.target.value)} className="w-full border rounded-lg px-3 py-2" autoComplete="name" />
                </div>
                <div>
                  <label htmlFor="address" className="block text-sm font-medium mb-1">Address</label>
                  <input id="address" value={address} onChange={(e) => setAddress(e.target.value)} className="w-full border rounded-lg px-3 py-2" autoComplete="street-address" />
                </div>
                <div>
                  <label htmlFor="eircode" className="block text-sm font-medium mb-1">Eircode (optional)</label>
                  <input id="eircode" value={eircode} onChange={(e) => setEircode(e.target.value)} className="w-full border rounded-lg px-3 py-2" placeholder="D02 XY12" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium mb-1">Phone</label>
                    <input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full border rounded-lg px-3 py-2" inputMode="tel" autoComplete="tel" />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
                    <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full border rounded-lg px-3 py-2" autoComplete="email" />
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label htmlFor="contactMethod" className="block text-sm font-medium mb-1">Preferred contact</label>
                  <select id="contactMethod" value={contactMethod} onChange={(e) => setContactMethod(e.target.value)} className="w-full border rounded-lg px-3 py-2">
                    <option>Phone</option>
                    <option>SMS</option>
                    <option>WhatsApp</option>
                    <option>Email</option>
                  </select>
                </div>
                <div className="flex items-center gap-2 mt-6">
                  <input id="emergency" type="checkbox" checked={emergency} onChange={(e) => setEmergency(e.target.checked)} className="h-4 w-4" />
                  <label htmlFor="emergency" className="flex items-center gap-2 cursor-pointer">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs ${emergency ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-700"}`}>Priority</span>
                    {emergency ? "Urgent" : "Normal"}
                  </label>
                </div>
                <div className="flex items-center gap-2 mt-6">
                  <input id="consent" type="checkbox" checked={!!consent} onChange={(e) => setConsent(e.target.checked)} className="h-4 w-4" />
                  <label htmlFor="consent" className="cursor-pointer">I consent to you contacting me and securely storing this request.</label>
                </div>
              </div>

              <div className="flex items-center justify-between gap-4">
                <p className="text-sm text-slate-600 flex items-center gap-2"><Icon name="map" className="w-4 h-4" /> Dublin & surrounding areas · Volunteers wear ID · Cashless options available</p>
                <button type="submit" className="inline-flex items-center gap-2 rounded-xl px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-medium shadow">
                  <Icon name="send" className="w-4 h-4" /> Submit request
                </button>
              </div>

              {submittedId && (
                <div role="status" aria-live="polite" className="mt-2 rounded-md bg-emerald-50 border border-emerald-200 p-3 text-emerald-800 flex items-start gap-2">
                  <span className="mt-0.5"><Icon name="check" className="w-5 h-5" /></span>
                  <div>
                    <p className="font-medium">Request received!</p>
                    <p className="text-sm">Your reference: <code className="px-1 py-0.5 bg-white rounded border">{submittedId}</code>. We'll be in touch soon.</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Info / Safety */}
          <div className="border rounded-2xl shadow-md bg-white">
            <div className="px-5 py-4 border-b">
              <div className="flex items-center gap-2 text-blue-700 font-medium"><Icon name="calendar" /><span>How it works</span></div>
            </div>
            <div className="p-5 space-y-3 text-slate-700">
              <ol className="list-decimal pl-5 space-y-2">
                <li>Submit your request. We confirm details via your preferred contact.</li>
                <li>A vetted volunteer collects items or completes the errand.</li>
                <li>Delivery to your door. We can leave items at the door for contact-free delivery.</li>
              </ol>
              <div className="rounded-lg border p-3 bg-slate-50">
                <p className="font-medium mb-1">Safety & privacy</p>
                <ul className="list-disc pl-5 space-y-1 text-sm">
                  <li>We only store what's necessary to fulfil your request.</li>
                  <li>Your data is never shared with third parties.</li>
                  <li>Volunteers will confirm your reference code on arrival.</li>
                </ul>
              </div>
            </div>
          </div>
        </form>

        {/* Volunteer / Admin Queue */}
        {volunteerMode && (
          <section className="space-y-4" aria-labelledby="queueHeading">
            <h2 id="queueHeading" className="text-xl md:text-2xl font-semibold tracking-tight">Request queue</h2>
            <div className="grid lg:grid-cols-2 gap-4">
              {pending.map((r) => (
                <div key={r.id} className={`border rounded-2xl shadow-sm bg-white ${r.emergency ? "ring-2 ring-rose-400" : ""}`}>
                  <div className="px-5 py-4 border-b flex items-center justify-between">
                    <div className="inline-flex items-center gap-2">
                      {r.type === "Medication" && <Icon name="stethoscope" className="w-4 h-4" />}
                      {r.type === "Groceries" && <Icon name="basket" className="w-4 h-4" />}
                      {r.type === "Errands" && <Icon name="clipboard" className="w-4 h-4" />}
                      {r.type === "Wellbeing Check" && <Icon name="heart" className="w-4 h-4" />}
                      <span className="font-medium">{r.type}</span>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${r.emergency ? "bg-rose-600 text-white" : "bg-slate-100 text-slate-700"}`}>{r.emergency ? "Urgent" : r.status}</span>
                  </div>
                  <div className="p-5 space-y-3">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <p className="font-medium">Items / tasks</p>
                        <p className="whitespace-pre-wrap">{r.items}</p>
                      </div>
                      <div>
                        <p className="font-medium">Notes</p>
                        <p className="whitespace-pre-wrap text-slate-700">{r.notes || "—"}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                      <p className="flex items-center gap-2"><Icon name="users" className="w-4 h-4" /> {r.name}</p>
                      <p className="flex items-center gap-2"><Icon name="map" className="w-4 h-4" /> {r.address}{r.eircode ? `, ${r.eircode}` : ""}</p>
                      <p className="flex items-center gap-2"><Icon name="phone" className="w-4 h-4" /> {r.contactMethod}{r.phone ? ` · ${r.phone}` : r.email ? ` · ${r.email}` : ""}</p>
                      <p className="flex items-center gap-2"><Icon name="calendar" className="w-4 h-4" /> {r.preferredDate || "Any day"} {r.preferredTime ? `· ${r.preferredTime}` : ""}</p>
                    </div>
                    <div className="flex gap-2 justify-end">
                      <button type="button" onClick={() => update(r.id, { status: r.status === "Queued" ? "Assigned" : "Queued" })} className="px-3 py-1.5 rounded-lg border bg-white hover:bg-slate-50">{r.status === "Queued" ? "Assign" : "Unassign"}</button>
                      <button type="button" onClick={() => update(r.id, { status: "Completed" })} className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 inline-flex items-center gap-1"><Icon name="check" className="w-4 h-4" /> Complete</button>
                      <button type="button" onClick={() => remove(r.id)} className="px-3 py-1.5 rounded-lg bg-rose-600 text-white hover:bg-rose-700">Delete</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {completed.length > 0 && (
              <div>
                <h3 className="text-lg font-medium mb-2">Completed</h3>
                <div className="grid lg:grid-cols-2 gap-4">
                  {completed.map((r) => (
                    <div key={r.id} className="border rounded-2xl shadow-sm bg-white">
                      <div className="px-5 py-4 border-b flex items-center justify-between">
                        <div className="inline-flex items-center gap-2"><Icon name="check" className="w-4 h-4" /><span className="font-medium">{r.type}</span></div>
                        <span className="text-xs px-2 py-1 rounded-full bg-slate-100 text-slate-700">Completed</span>
                      </div>
                      <div className="p-5 text-sm text-slate-700 space-y-1">
                        <p><strong>For:</strong> {r.name}</p>
                        <p><strong>Address:</strong> {r.address}{r.eircode ? `, ${r.eircode}` : ""}</p>
                        <p><strong>Items:</strong> {r.items}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>
        )}

        <footer className="py-6 text-center text-sm text-slate-600">Built for accessibility: keyboard-friendly, screen-reader labels, high-contrast & large-text modes.</footer>
      </div>
    </div>
  );
}
